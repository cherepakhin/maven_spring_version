package ru.perm.v.maven_spring302_j11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenSpring302J11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
