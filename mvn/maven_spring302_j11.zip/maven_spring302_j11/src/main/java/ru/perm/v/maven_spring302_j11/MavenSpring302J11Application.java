package ru.perm.v.maven_spring302_j11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenSpring302J11Application {

	public static void main(String[] args) {
		SpringApplication.run(MavenSpring302J11Application.class, args);
	}

}
